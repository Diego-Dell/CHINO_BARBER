// src/db.js
// ✅ ÚNICA conexión SQLite para TODO el backend (routes + server)
// - Usa el mismo DB_PATH que config
// - Aplica schema base (CREATE TABLE IF NOT EXISTS)
// - Ejecuta migraciones seguras (ALTER TABLE si falta columna) SIN borrar datos

const sqlite3 = require("sqlite3").verbose();
const config = require("./services/config");
const fs = require("fs");
const path = require("path");

// ===============================
// helpers
// ===============================
function tableExists(db, table) {
  return new Promise((resolve) => {
    db.get(
      `SELECT name FROM sqlite_master WHERE type='table' AND name=?`,
      [table],
      (err, row) => {
        if (err) return resolve(false);
        resolve(!!row);
      }
    );
  });
}

function columnExists(db, table, column) {
  return new Promise((resolve) => {
    db.all(`PRAGMA table_info(${table});`, (err, rows) => {
      if (err || !rows) return resolve(false);
      resolve(rows.some((r) => r.name === column));
    });
  });
}

function run(db, sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) return reject(err);
      resolve({ changes: this.changes, lastID: this.lastID });
    });
  });
}

// ===============================
// open DB
// ===============================
const db = new sqlite3.Database(config.DB_PATH, async (err) => {
  if (err) {
    console.error("[DB] open error:", err.message);
    return;
  }

  console.log("[DB] OK:", config.DB_PATH);

  // evita SQLITE_BUSY cuando la DB está siendo usada
  try { db.configure("busyTimeout", 5000); } catch (_) {}
  try { db.run("PRAGMA busy_timeout = 5000;"); } catch (_) {}

  // PRAGMAs recomendados
  db.serialize(() => {
    try { db.run("PRAGMA foreign_keys = ON;"); } catch (_) {}
    try { db.run("PRAGMA journal_mode = WAL;"); } catch (_) {}
    try { db.run("PRAGMA synchronous = NORMAL;"); } catch (_) {}
  });

  // 1) Aplicar schema BASE (solo CREATE TABLE/INDEX/INSERT OR IGNORE)
  await applyBaseSchema();

  // 2) Ejecutar migraciones seguras (ALTER TABLE si falta algo)
  await runMigrationsSafe();

  console.log("[DB] listo ✅");
});

// ===============================
// schema base (sin ALTERs)
// ===============================
async function applyBaseSchema() {
  try {
    const schemaPath = path.join(config.DB_DIR, "schema.sql");

    if (!fs.existsSync(schemaPath)) {
      console.warn("[DB] schema.sql no encontrado en:", schemaPath);
      return;
    }

    let schema = fs.readFileSync(schemaPath, "utf8");

    // ✅ IMPORTANTE:
    // Quitamos cualquier ALTER TABLE del schema para que no falle en cada arranque.
    // Las migraciones se manejan abajo.
    schema = schema
      .split("\n")
      .filter((line) => !line.trim().toUpperCase().startsWith("ALTER TABLE"))
      .join("\n");

    await new Promise((resolve) => {
      db.exec(schema, (e) => {
        if (e) console.error("[DB] schema base error:", e.message);
        else console.log("[DB] schema base aplicado/ok");
        resolve(true);
      });
    });
  } catch (e) {
    console.error("[DB] schema init error:", e.message);
  }
}

// ===============================
// migraciones seguras (SIN perder datos)
// ===============================
async function runMigrationsSafe() {
  try {
    // MIGRACIÓN 1: cursos.fecha_inicio
    if (await tableExists(db, "cursos")) {
      const hasFechaInicio = await columnExists(db, "cursos", "fecha_inicio");
      if (!hasFechaInicio) {
        try {
          await run(db, `ALTER TABLE cursos ADD COLUMN fecha_inicio TEXT;`);
          console.log("[DB] migración OK: cursos.fecha_inicio");
        } catch (e) {
          // Si ya existe por carrera, lo ignoramos
          if (!String(e.message).toLowerCase().includes("duplicate")) {
            console.error("[DB] migración error cursos.fecha_inicio:", e.message);
          }
        }
      }
    }
    
    // MIGRACIÓN: asistencia.fecha + índice
if (await tableExists(db, "asistencia")) {
  const hasFecha = await columnExists(db, "asistencia", "fecha");

  if (!hasFecha) {
    try {
      await run(db, `ALTER TABLE asistencia ADD COLUMN fecha TEXT;`);
      console.log("[DB] migración OK: asistencia.fecha");
    } catch (e) {
      if (!String(e.message).toLowerCase().includes("duplicate")) {
        console.error("[DB] migración error asistencia.fecha:", e.message);
      }
    }
  }

  // Crear índice SOLO si la columna existe
  try {
    await run(
      db,
      `CREATE UNIQUE INDEX IF NOT EXISTS ux_asistencia_inscripcion_fecha
       ON asistencia(inscripcion_id, fecha);`
    );
    console.log("[DB] índice OK: ux_asistencia_inscripcion_fecha");
  } catch (e) {
    console.error("[DB] índice error asistencia:", e.message);
  }
}

    // MIGRACIÓN 2 (ejemplo): si tu error era "no such column: fecha"
    // OJO: en tu schema ya existe "fecha" en varias tablas, así que el error
    // probablemente viene de una tabla que en tu DB vieja no tenía esa columna.
    //
    // 👉 Ajusta AQUÍ el nombre real de la tabla donde te falla "fecha".
    //
    // Ejemplo si fuera "inventario_movimientos.fecha":
    // if (await tableExists(db, "inventario_movimientos")) {
    //   const hasFecha = await columnExists(db, "inventario_movimientos", "fecha");
    //   if (!hasFecha) {
    //     await run(db, `ALTER TABLE inventario_movimientos ADD COLUMN fecha TEXT;`);
    //     console.log("[DB] migración OK: inventario_movimientos.fecha");
    //   }
    // }

  } catch (e) {
    console.error("[DB] runMigrationsSafe error:", e.message);
  }
}

module.exports = db;
