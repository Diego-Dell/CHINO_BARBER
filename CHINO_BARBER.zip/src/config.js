// services/config.js
// Configuración central del backend (server + routes + backup).
// Compatible Node / Electron / Windows / Linux.
// Lee process.env (Electron define DB_DIR y DB_PATH).

const fs = require("fs");
const path = require("path");

// ===============================
// Base dirs
// ===============================
const SERVICES_DIR = __dirname;

// Intento 1: asumir que /services está dentro del root del proyecto
const ROOT_DIR_FROM_SERVICES = path.resolve(SERVICES_DIR, "..");

// Intento 2: process.cwd() (cuando inicias node desde el root)
const ROOT_DIR_FROM_CWD = path.resolve(process.cwd());

// Heurística para detectar ROOT real
function pickRootDir() {
  try {
    const cand1 = path.join(ROOT_DIR_FROM_CWD, "services");
    const cand2 = path.join(ROOT_DIR_FROM_CWD, "src", "services");

    if (
      (fs.existsSync(cand1) && fs.statSync(cand1).isDirectory()) ||
      (fs.existsSync(cand2) && fs.statSync(cand2).isDirectory())
    ) {
      return ROOT_DIR_FROM_CWD;
    }
  } catch (_) {}
  return ROOT_DIR_FROM_SERVICES;
}

const ROOT_DIR = pickRootDir();

// ===============================
// Helpers
// ===============================
function resolvePath(...parts) {
  return path.join(ROOT_DIR, ...parts);
}

function ensureDir(dirPath) {
  if (!dirPath) return;
  fs.mkdirSync(dirPath, { recursive: true });
}

function isProduction() {
  return String(process.env.NODE_ENV || "").toLowerCase() === "production";
}

function isValidPath(p) {
  if (!p || typeof p !== "string") return false;
  const s = p.trim();
  if (!s) return false;
  if (s.includes("\0")) return false;
  return true;
}

// ===============================
// Directories (override por env)
// ===============================
const PUBLIC_DIR =
  process.env.PUBLIC_DIR && isValidPath(process.env.PUBLIC_DIR)
    ? path.resolve(process.env.PUBLIC_DIR)
    : resolvePath("public");

// ⚠️ CLAVE PARA ELECTRON:
// Electron define process.env.DB_DIR apuntando a AppData
const DB_DIR =
  process.env.DB_DIR && isValidPath(process.env.DB_DIR)
    ? path.resolve(process.env.DB_DIR)
    : resolvePath("db");

// ===============================
// DB_PATH (CRÍTICO)
// Prioridad: DB_PATH -> SQLITE_PATH -> DB_DIR/database.sqlite
// ===============================
let DB_PATH = null;

if (isValidPath(process.env.DB_PATH)) {
  DB_PATH = path.resolve(process.env.DB_PATH.trim());
} else if (isValidPath(process.env.SQLITE_PATH)) {
  DB_PATH = path.resolve(process.env.SQLITE_PATH.trim());
} else {
  DB_PATH = path.join(DB_DIR, "database.sqlite");
}

// Asegurar carpeta de la BD
ensureDir(path.dirname(DB_PATH));

// ===============================
// BACKUP_DIR
// ===============================
const BACKUP_DIR =
  isValidPath(process.env.BACKUP_DIR)
    ? path.resolve(process.env.BACKUP_DIR.trim())
    : resolvePath("backups");

ensureDir(BACKUP_DIR);

// ===============================
// Server settings
// ===============================
const PORT = Number(process.env.PORT) > 0 ? Number(process.env.PORT) : 3000;
const NODE_ENV = process.env.NODE_ENV ? String(process.env.NODE_ENV) : "development";
const BASE_URL =
  process.env.BASE_URL && isValidPath(process.env.BASE_URL)
    ? String(process.env.BASE_URL).trim()
    : `http://localhost:${PORT}`;

// ===============================
// Logs flags
// ===============================
const LOG_LEVEL =
  (process.env.LOG_LEVEL && String(process.env.LOG_LEVEL).trim()) || "info";

const DEBUG = String(process.env.DEBUG || "").toLowerCase() === "true";

// ===============================
// Config object
// ===============================
const config = {
  SERVICES_DIR,
  ROOT_DIR,
  PUBLIC_DIR,
  DB_DIR,

  DB_PATH,
  BACKUP_DIR,

  PORT,
  NODE_ENV,
  BASE_URL,

  LOG_LEVEL,
  DEBUG,

  resolvePath,
  ensureDir,
  isProduction
};

// Validación final de seguridad
if (!isValidPath(config.DB_PATH)) {
  config.DB_PATH = path.join(config.DB_DIR, "database.sqlite");
  ensureDir(path.dirname(config.DB_PATH));
}

module.exports = config;
