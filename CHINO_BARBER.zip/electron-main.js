const { app, BrowserWindow, dialog } = require("electron");
const path = require("path");
const fs = require("fs");
const http = require("http");
const { spawn } = require("child_process");

const log = require("electron-log");
const { autoUpdater } = require("electron-updater");

log.transports.file.level = "info";
autoUpdater.logger = log;

let mainWindow = null;
let serverProcess = null;

// ✅ SINGLE INSTANCE (evita doble cache, doble servidor, etc.)
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on("second-instance", () => {
    if (mainWindow) {
      if (mainWindow.isMinimized()) mainWindow.restore();
      mainWindow.focus();
    }
  });
}

// Paths usuario
const userData = app.getPath("userData");
const DB_DIR = path.join(userData, "db");
const LOG_DIR = path.join(userData, "logs");
const CACHE_DIR = path.join(userData, "cache");

function ensureDir(p) {
  try { fs.mkdirSync(p, { recursive: true }); } catch (_) {}
}

ensureDir(DB_DIR);
ensureDir(LOG_DIR);
ensureDir(CACHE_DIR);

// ✅ Cache dir fijo (reduce "Acceso denegado (0x5)")
app.commandLine.appendSwitch("disk-cache-dir", CACHE_DIR);

// Env para backend
process.env.APP_USER_DATA = userData;
process.env.DB_DIR = DB_DIR;
process.env.DB_PATH = path.join(DB_DIR, "database.sqlite");
process.env.NODE_ENV = "production";

// ✅ puerto libre
process.env.PORT = "0";

// ---- helpers ----
function httpGet(url, timeoutMs = 1200) {
  return new Promise((resolve, reject) => {
    const req = http.get(url, (res) => {
      let data = "";
      res.on("data", (c) => (data += c));
      res.on("end", () => resolve({ status: res.statusCode, data }));
    });
    req.on("error", reject);
    req.setTimeout(timeoutMs, () => req.destroy(new Error("timeout")));
  });
}

function readPortFile(timeoutMs = 15000) {
  const portFile = path.join(userData, "server-port.txt");
  const start = Date.now();

  return new Promise((resolve, reject) => {
    const t = setInterval(() => {
      try {
        if (fs.existsSync(portFile)) {
          const p = Number(String(fs.readFileSync(portFile, "utf8")).trim());
          if (p > 0) {
            clearInterval(t);
            return resolve(p);
          }
        }
      } catch (_) {}

      if (Date.now() - start > timeoutMs) {
        clearInterval(t);
        reject(new Error("No se pudo leer server-port.txt a tiempo"));
      }
    }, 250);
  });
}

async function waitForServer(port, timeoutMs = 20000) {
  const healthUrl = `http://localhost:${port}/health`;
  const start = Date.now();

  while (Date.now() - start < timeoutMs) {
    try {
      const res = await httpGet(healthUrl, 1200);
      if (res.status === 200) {
        try {
          const json = JSON.parse(res.data || "{}");
          if (json.ok) return true;
        } catch (_) {
          // si no parsea, igual está vivo: reintenta
        }
      }
    } catch (_) {}
    await new Promise((r) => setTimeout(r, 350));
  }

  throw new Error("Server did not respond in time");
}

function startServer() {
  return new Promise((resolve, reject) => {
    try {
      // limpiar port file viejo
      try { fs.unlinkSync(path.join(userData, "server-port.txt")); } catch (_) {}

      const serverPath = app.isPackaged
        ? path.join(process.resourcesPath, "app.asar", "services", "server.js")
        : path.join(__dirname, "services", "server.js");

      log.info("Starting server:", serverPath);

      const out = fs.openSync(path.join(LOG_DIR, "server.out.log"), "a");
      const err = fs.openSync(path.join(LOG_DIR, "server.err.log"), "a");

      serverProcess = spawn(process.execPath, [serverPath], {
        env: process.env,
        windowsHide: true,
        stdio: ["ignore", out, err],
      });

      serverProcess.on("error", (e) => {
        log.error("Server spawn error:", e);
        reject(e);
      });

      serverProcess.on("exit", (code) => {
        log.error("Server exit:", code);
      });

      resolve();
    } catch (e) {
      reject(e);
    }
  });
}

function createWindow(port) {
  const serverUrl = `http://localhost:${port}`;

  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    show: false,
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
    },
  });

  mainWindow.loadURL(serverUrl);
  mainWindow.once("ready-to-show", () => mainWindow.show());
}

// ---- lifecycle ----
app.whenReady().then(async () => {
  try {
    await startServer();

    const port = await readPortFile(15000);
    await waitForServer(port, 25000);

    createWindow(port);

    if (app.isPackaged) {
      autoUpdater.checkForUpdatesAndNotify();
    }
  } catch (err) {
    log.error("Startup error:", err);

    dialog.showErrorBox(
      "No se pudo iniciar el sistema",
      "El servidor local no respondió.\n\nRevisa estos logs:\n" +
        `${LOG_DIR}\\main.log\n` +
        `${LOG_DIR}\\server.out.log\n` +
        `${LOG_DIR}\\server.err.log\n`
    );

    app.quit();
  }
});

app.on("before-quit", () => {
  try { if (serverProcess) serverProcess.kill(); } catch (_) {}
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
